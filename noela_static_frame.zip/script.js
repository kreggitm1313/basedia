const upload = document.getElementById("upload");
const preview = document.getElementById("preview");

upload.addEventListener("change", (event) => {
  const file = event.target.files[0];
  if (!file) return;

  const img = document.createElement("img");
  img.src = URL.createObjectURL(file);
  preview.innerHTML = "";
  preview.appendChild(img);
});